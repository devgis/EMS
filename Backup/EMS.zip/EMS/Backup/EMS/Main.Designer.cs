﻿namespace EMS
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.系统ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.权限管理QToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.重新登陆CToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.退出系统TToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.设备EToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.录入设备ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.编辑设备ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.设备处理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.设备查询ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.处理日志LToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.人员PToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.人员录入ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.人员编辑ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.人员查找SToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.租赁LToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.设备租赁ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.设备归还ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.状态查询ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.日志查看ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.资料BToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.设备类别ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.设备品牌ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.规格型号ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.使用属性ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.报表打印RToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.固定资产使用登记簿GToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.清查明细表QToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.帮助HToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.帮助HToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.关于AToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel3 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel4 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel5 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel6 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel7 = new System.Windows.Forms.ToolStripStatusLabel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.menuStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.系统ToolStripMenuItem,
            this.设备EToolStripMenuItem,
            this.人员PToolStripMenuItem,
            this.租赁LToolStripMenuItem,
            this.资料BToolStripMenuItem,
            this.报表打印RToolStripMenuItem,
            this.帮助HToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(612, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 系统ToolStripMenuItem
            // 
            this.系统ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.权限管理QToolStripMenuItem,
            this.toolStripMenuItem2,
            this.重新登陆CToolStripMenuItem,
            this.退出系统TToolStripMenuItem});
            this.系统ToolStripMenuItem.Name = "系统ToolStripMenuItem";
            this.系统ToolStripMenuItem.Size = new System.Drawing.Size(83, 20);
            this.系统ToolStripMenuItem.Text = "系统管理(&S)";
            // 
            // 权限管理QToolStripMenuItem
            // 
            this.权限管理QToolStripMenuItem.Name = "权限管理QToolStripMenuItem";
            this.权限管理QToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.权限管理QToolStripMenuItem.Text = "权限管理(&Q)";
            this.权限管理QToolStripMenuItem.Click += new System.EventHandler(this.权限管理QToolStripMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(136, 22);
            this.toolStripMenuItem2.Text = "修改密码(&P)";
            this.toolStripMenuItem2.Click += new System.EventHandler(this.toolStripMenuItem2_Click);
            // 
            // 重新登陆CToolStripMenuItem
            // 
            this.重新登陆CToolStripMenuItem.Name = "重新登陆CToolStripMenuItem";
            this.重新登陆CToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.重新登陆CToolStripMenuItem.Text = "重新登陆(&C)";
            this.重新登陆CToolStripMenuItem.Click += new System.EventHandler(this.重新登陆CToolStripMenuItem_Click);
            // 
            // 退出系统TToolStripMenuItem
            // 
            this.退出系统TToolStripMenuItem.Name = "退出系统TToolStripMenuItem";
            this.退出系统TToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.退出系统TToolStripMenuItem.Text = "退出系统(&T)";
            this.退出系统TToolStripMenuItem.Click += new System.EventHandler(this.退出系统TToolStripMenuItem_Click);
            // 
            // 设备EToolStripMenuItem
            // 
            this.设备EToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.录入设备ToolStripMenuItem,
            this.编辑设备ToolStripMenuItem,
            this.设备处理ToolStripMenuItem,
            this.设备查询ToolStripMenuItem,
            this.处理日志LToolStripMenuItem});
            this.设备EToolStripMenuItem.Name = "设备EToolStripMenuItem";
            this.设备EToolStripMenuItem.Size = new System.Drawing.Size(83, 20);
            this.设备EToolStripMenuItem.Text = "设备管理(&E)";
            // 
            // 录入设备ToolStripMenuItem
            // 
            this.录入设备ToolStripMenuItem.Name = "录入设备ToolStripMenuItem";
            this.录入设备ToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.录入设备ToolStripMenuItem.Text = "录入设备(&E)";
            this.录入设备ToolStripMenuItem.Click += new System.EventHandler(this.录入设备ToolStripMenuItem_Click);
            // 
            // 编辑设备ToolStripMenuItem
            // 
            this.编辑设备ToolStripMenuItem.Name = "编辑设备ToolStripMenuItem";
            this.编辑设备ToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.编辑设备ToolStripMenuItem.Text = "编辑设备(&E)";
            this.编辑设备ToolStripMenuItem.Click += new System.EventHandler(this.编辑设备ToolStripMenuItem_Click);
            // 
            // 设备处理ToolStripMenuItem
            // 
            this.设备处理ToolStripMenuItem.Name = "设备处理ToolStripMenuItem";
            this.设备处理ToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.设备处理ToolStripMenuItem.Text = "设备处理(&D)";
            this.设备处理ToolStripMenuItem.Click += new System.EventHandler(this.设备处理ToolStripMenuItem_Click);
            // 
            // 设备查询ToolStripMenuItem
            // 
            this.设备查询ToolStripMenuItem.Name = "设备查询ToolStripMenuItem";
            this.设备查询ToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.设备查询ToolStripMenuItem.Text = "设备查询(&S)";
            this.设备查询ToolStripMenuItem.Click += new System.EventHandler(this.设备查询ToolStripMenuItem_Click);
            // 
            // 处理日志LToolStripMenuItem
            // 
            this.处理日志LToolStripMenuItem.Name = "处理日志LToolStripMenuItem";
            this.处理日志LToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.处理日志LToolStripMenuItem.Text = "处理日志(&L)";
            this.处理日志LToolStripMenuItem.Click += new System.EventHandler(this.处理日志LToolStripMenuItem_Click);
            // 
            // 人员PToolStripMenuItem
            // 
            this.人员PToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.人员录入ToolStripMenuItem,
            this.人员编辑ToolStripMenuItem,
            this.人员查找SToolStripMenuItem});
            this.人员PToolStripMenuItem.Name = "人员PToolStripMenuItem";
            this.人员PToolStripMenuItem.Size = new System.Drawing.Size(83, 20);
            this.人员PToolStripMenuItem.Text = "人员管理(&P)";
            // 
            // 人员录入ToolStripMenuItem
            // 
            this.人员录入ToolStripMenuItem.Name = "人员录入ToolStripMenuItem";
            this.人员录入ToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.人员录入ToolStripMenuItem.Text = "人员录入(&I)";
            this.人员录入ToolStripMenuItem.Click += new System.EventHandler(this.人员录入ToolStripMenuItem_Click);
            // 
            // 人员编辑ToolStripMenuItem
            // 
            this.人员编辑ToolStripMenuItem.Name = "人员编辑ToolStripMenuItem";
            this.人员编辑ToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.人员编辑ToolStripMenuItem.Text = "人员编辑(&E)";
            this.人员编辑ToolStripMenuItem.Click += new System.EventHandler(this.人员编辑ToolStripMenuItem_Click);
            // 
            // 人员查找SToolStripMenuItem
            // 
            this.人员查找SToolStripMenuItem.Name = "人员查找SToolStripMenuItem";
            this.人员查找SToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.人员查找SToolStripMenuItem.Text = "人员查找(&S)";
            this.人员查找SToolStripMenuItem.Click += new System.EventHandler(this.人员查找SToolStripMenuItem_Click);
            // 
            // 租赁LToolStripMenuItem
            // 
            this.租赁LToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.设备租赁ToolStripMenuItem,
            this.设备归还ToolStripMenuItem,
            this.状态查询ToolStripMenuItem,
            this.日志查看ToolStripMenuItem});
            this.租赁LToolStripMenuItem.Name = "租赁LToolStripMenuItem";
            this.租赁LToolStripMenuItem.Size = new System.Drawing.Size(83, 20);
            this.租赁LToolStripMenuItem.Text = "租赁管理(&L)";
            // 
            // 设备租赁ToolStripMenuItem
            // 
            this.设备租赁ToolStripMenuItem.Name = "设备租赁ToolStripMenuItem";
            this.设备租赁ToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.设备租赁ToolStripMenuItem.Text = "设备租赁(&L)";
            this.设备租赁ToolStripMenuItem.Click += new System.EventHandler(this.设备租赁ToolStripMenuItem_Click);
            // 
            // 设备归还ToolStripMenuItem
            // 
            this.设备归还ToolStripMenuItem.Name = "设备归还ToolStripMenuItem";
            this.设备归还ToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.设备归还ToolStripMenuItem.Text = "设备归还(&R)";
            this.设备归还ToolStripMenuItem.Click += new System.EventHandler(this.设备归还ToolStripMenuItem_Click);
            // 
            // 状态查询ToolStripMenuItem
            // 
            this.状态查询ToolStripMenuItem.Name = "状态查询ToolStripMenuItem";
            this.状态查询ToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.状态查询ToolStripMenuItem.Text = "状态查询(&S)";
            this.状态查询ToolStripMenuItem.Click += new System.EventHandler(this.状态查询ToolStripMenuItem_Click);
            // 
            // 日志查看ToolStripMenuItem
            // 
            this.日志查看ToolStripMenuItem.Name = "日志查看ToolStripMenuItem";
            this.日志查看ToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.日志查看ToolStripMenuItem.Text = "日志查看(&L)";
            this.日志查看ToolStripMenuItem.Click += new System.EventHandler(this.日志查看ToolStripMenuItem_Click);
            // 
            // 资料BToolStripMenuItem
            // 
            this.资料BToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.设备类别ToolStripMenuItem,
            this.设备品牌ToolStripMenuItem,
            this.规格型号ToolStripMenuItem,
            this.使用属性ToolStripMenuItem});
            this.资料BToolStripMenuItem.Name = "资料BToolStripMenuItem";
            this.资料BToolStripMenuItem.Size = new System.Drawing.Size(83, 20);
            this.资料BToolStripMenuItem.Text = "基础资料(&B)";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(136, 22);
            this.toolStripMenuItem1.Text = "部门科室(&D)";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // 设备类别ToolStripMenuItem
            // 
            this.设备类别ToolStripMenuItem.Name = "设备类别ToolStripMenuItem";
            this.设备类别ToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.设备类别ToolStripMenuItem.Text = "设备类别(&T)";
            this.设备类别ToolStripMenuItem.Click += new System.EventHandler(this.设备类别ToolStripMenuItem_Click);
            // 
            // 设备品牌ToolStripMenuItem
            // 
            this.设备品牌ToolStripMenuItem.Name = "设备品牌ToolStripMenuItem";
            this.设备品牌ToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.设备品牌ToolStripMenuItem.Text = "设备品牌(&L)";
            this.设备品牌ToolStripMenuItem.Click += new System.EventHandler(this.设备品牌ToolStripMenuItem_Click);
            // 
            // 规格型号ToolStripMenuItem
            // 
            this.规格型号ToolStripMenuItem.Name = "规格型号ToolStripMenuItem";
            this.规格型号ToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.规格型号ToolStripMenuItem.Text = "规格型号(&M)";
            this.规格型号ToolStripMenuItem.Click += new System.EventHandler(this.规格型号ToolStripMenuItem_Click);
            // 
            // 使用属性ToolStripMenuItem
            // 
            this.使用属性ToolStripMenuItem.Name = "使用属性ToolStripMenuItem";
            this.使用属性ToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.使用属性ToolStripMenuItem.Text = "使用属性(&U)";
            this.使用属性ToolStripMenuItem.Click += new System.EventHandler(this.使用属性ToolStripMenuItem_Click);
            // 
            // 报表打印RToolStripMenuItem
            // 
            this.报表打印RToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.固定资产使用登记簿GToolStripMenuItem,
            this.清查明细表QToolStripMenuItem});
            this.报表打印RToolStripMenuItem.Name = "报表打印RToolStripMenuItem";
            this.报表打印RToolStripMenuItem.Size = new System.Drawing.Size(83, 20);
            this.报表打印RToolStripMenuItem.Text = "报表打印(&R)";
            // 
            // 固定资产使用登记簿GToolStripMenuItem
            // 
            this.固定资产使用登记簿GToolStripMenuItem.Name = "固定资产使用登记簿GToolStripMenuItem";
            this.固定资产使用登记簿GToolStripMenuItem.Size = new System.Drawing.Size(196, 22);
            this.固定资产使用登记簿GToolStripMenuItem.Text = "固定资产使用登记簿(&G)";
            this.固定资产使用登记簿GToolStripMenuItem.Click += new System.EventHandler(this.固定资产使用登记簿GToolStripMenuItem_Click);
            // 
            // 清查明细表QToolStripMenuItem
            // 
            this.清查明细表QToolStripMenuItem.Name = "清查明细表QToolStripMenuItem";
            this.清查明细表QToolStripMenuItem.Size = new System.Drawing.Size(196, 22);
            this.清查明细表QToolStripMenuItem.Text = "清查明细表(&Q)";
            this.清查明细表QToolStripMenuItem.Click += new System.EventHandler(this.清查明细表QToolStripMenuItem_Click);
            // 
            // 帮助HToolStripMenuItem
            // 
            this.帮助HToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.帮助HToolStripMenuItem1,
            this.toolStripSeparator1,
            this.关于AToolStripMenuItem});
            this.帮助HToolStripMenuItem.Name = "帮助HToolStripMenuItem";
            this.帮助HToolStripMenuItem.Size = new System.Drawing.Size(59, 20);
            this.帮助HToolStripMenuItem.Text = "帮助(&H)";
            // 
            // 帮助HToolStripMenuItem1
            // 
            this.帮助HToolStripMenuItem1.Name = "帮助HToolStripMenuItem1";
            this.帮助HToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.帮助HToolStripMenuItem1.Text = "帮助(&H)";
            this.帮助HToolStripMenuItem1.Click += new System.EventHandler(this.帮助HToolStripMenuItem1_Click);
            // 
            // 关于AToolStripMenuItem
            // 
            this.关于AToolStripMenuItem.Name = "关于AToolStripMenuItem";
            this.关于AToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.关于AToolStripMenuItem.Text = "关于(&A)";
            this.关于AToolStripMenuItem.Click += new System.EventHandler(this.关于AToolStripMenuItem_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.toolStripStatusLabel2,
            this.toolStripStatusLabel3,
            this.toolStripStatusLabel4,
            this.toolStripStatusLabel5,
            this.toolStripStatusLabel6,
            this.toolStripStatusLabel7});
            this.statusStrip1.Location = new System.Drawing.Point(0, 418);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(612, 22);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(119, 17);
            this.toolStripStatusLabel1.Text = "2009@FLY  当前用户:";
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(29, 17);
            this.toolStripStatusLabel2.Text = "USER";
            // 
            // toolStripStatusLabel3
            // 
            this.toolStripStatusLabel3.Name = "toolStripStatusLabel3";
            this.toolStripStatusLabel3.Size = new System.Drawing.Size(101, 17);
            this.toolStripStatusLabel3.Text = "       系统日期:";
            // 
            // toolStripStatusLabel4
            // 
            this.toolStripStatusLabel4.Name = "toolStripStatusLabel4";
            this.toolStripStatusLabel4.Size = new System.Drawing.Size(29, 17);
            this.toolStripStatusLabel4.Text = "DATE";
            // 
            // toolStripStatusLabel5
            // 
            this.toolStripStatusLabel5.Name = "toolStripStatusLabel5";
            this.toolStripStatusLabel5.Size = new System.Drawing.Size(101, 17);
            this.toolStripStatusLabel5.Text = "      当前时间：";
            // 
            // toolStripStatusLabel6
            // 
            this.toolStripStatusLabel6.Name = "toolStripStatusLabel6";
            this.toolStripStatusLabel6.Size = new System.Drawing.Size(29, 17);
            this.toolStripStatusLabel6.Text = "TIME";
            // 
            // toolStripStatusLabel7
            // 
            this.toolStripStatusLabel7.Name = "toolStripStatusLabel7";
            this.toolStripStatusLabel7.Size = new System.Drawing.Size(395, 12);
            this.toolStripStatusLabel7.Text = "                                                                 ";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(149, 6);
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(612, 440);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "电子设备管理系统";
            this.Load += new System.EventHandler(this.Main_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripMenuItem 系统ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 权限管理QToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 重新登陆CToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 退出系统TToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 设备EToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 人员PToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 租赁LToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 资料BToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 帮助HToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 录入设备ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 编辑设备ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 设备处理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 设备查询ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 人员录入ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 人员编辑ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 人员查找SToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 处理日志LToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 设备租赁ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 设备归还ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 状态查询ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 日志查看ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 设备类别ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 设备品牌ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 规格型号ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 使用属性ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 帮助HToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 关于AToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel3;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel4;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel5;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel6;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel7;
        private System.Windows.Forms.ToolStripMenuItem 报表打印RToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 固定资产使用登记簿GToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 清查明细表QToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
    }
}