﻿namespace EMS.cs {
    
    
    public partial class EMSDS {
        partial class equiprlogoDataTable
        {
        }
    }
}
